const { Telegraf, Markup } = require("telegraf");
const sqlite3 = require("sqlite3").verbose();
const db = new sqlite3.Database("./vikt.db");

const bot = new Telegraf("7813189708:AAEWX_EGLvGC5VjqPRtFFcZMBX3yjHy8RQw");

db.serialize(() => {
  db.run(`
        CREATE TABLE IF NOT EXISTS users (
            telegram_id INTEGER PRIMARY KEY,
            username TEXT,
            name TEXT,
            age INTEGER,
            score INTEGER DEFAULT 0,
            correct_answers INTEGER DEFAULT 0,
            incorrect_answers INTEGER DEFAULT 0,
            quiz_state TEXT DEFAULT 'not_started'
        )
    `);

  db.run(`
        CREATE TABLE IF NOT EXISTS questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question TEXT,
            option1 TEXT,
            option2 TEXT,
            option3 TEXT,
            correct_option INTEGER
        )
    `);
});

async function registerUser(userId, username) {
  return new Promise((resolve, reject) => {
    db.get(
      "SELECT * FROM users WHERE telegram_id = ?",
      [userId],
      (err, row) => {
        if (err) {
          return reject(err);
        }
        if (row) {
          return resolve();
        }

        db.run(
          `INSERT INTO users (telegram_id, username) VALUES (?, ?)`,
          [userId, username],
          (err) => {
            if (err) reject(err);
            resolve();
          }
        );
      }
    );
  });
}

bot.start(async (ctx) => {
  const userId = ctx.from.id;
  const username = ctx.from.username;

  try {
    await registerUser(userId, username);
    ctx.reply(
      'Добро пожаловать! Вы успешно зарегистрированы. Нажмите "🎯 Начать викторину", чтобы начать.',
      Markup.keyboard([
        ["🎯 Начать викторину", "👤 Мой профиль"],
        ["📊 Статистика", "📝 Редактировать профиль"],
        ["❓ Помощь"],
      ]).resize()
    );
  } catch (error) {
    console.error("Ошибка при регистрации:", error);
    ctx.reply("❗ Произошла ошибка при регистрации.");
  }
});

bot.hears("👤 Мой профиль", async (ctx) => {
  const userId = ctx.from.id;
  try {
    const user = await new Promise((resolve, reject) => {
      db.get(
        "SELECT * FROM users WHERE telegram_id = ?",
        [userId],
        (err, row) => {
          if (err) reject(err);
          resolve(row);
        }
      );
    });

    if (user) {
      ctx.reply(
        `📝 Ваш профиль:
- Имя: ${user.name || "Не указано"}
- Возраст: ${user.age || "Не указан"}
- Баллы: ${user.score || 0}
- Правильных ответов: ${user.correct_answers || 0}
- Неправильных ответов: ${user.incorrect_answers || 0}`,
        Markup.keyboard([
          ["🎯 Начать викторину", "👤 Мой профиль"],
          ["📊 Статистика", "📝 Редактировать профиль"],
          ["❓ Помощь"],
        ]).resize()
      );
    } else {
      ctx.reply(
        "❗ Ваш профиль не найден. Пожалуйста, начните регистрацию с команды /start."
      );
    }
  } catch (error) {
    console.error(error);
    ctx.reply("❗ Произошла ошибка при получении данных профиля.");
  }
});

let editState = {};

bot.hears("📝 Редактировать профиль", async (ctx) => {
  const userId = ctx.from.id;
  try {
    const user = await new Promise((resolve, reject) => {
      db.get(
        "SELECT * FROM users WHERE telegram_id = ?",
        [userId],
        (err, row) => {
          if (err) reject(err);
          resolve(row);
        }
      );
    });

    if (user) {
      editState[userId] = "name";
      ctx.reply(
        'Вы можете отредактировать ваше имя и возраст. Напишите новое имя (или напишите "пропустить" для сохранения текущего):'
      );

      bot.on("text", async (msgCtx) => {
        const userInput = msgCtx.message.text;
        const currentStep = editState[userId];

        if (currentStep === "name") {
          if (userInput.toLowerCase() !== "пропустить") {
            await new Promise((resolve, reject) => {
              db.run(
                "UPDATE users SET name = ? WHERE telegram_id = ?",
                [userInput, userId],
                (err) => {
                  if (err) reject(err);
                  resolve();
                }
              );
            });
            msgCtx.reply(`Имя успешно обновлено на: ${userInput}`);
          }

          editState[userId] = "age";
          msgCtx.reply(
            'Теперь напишите ваш возраст (или напишите "пропустить" для сохранения текущего):'
          );
        } else if (currentStep === "age") {
          if (userInput.toLowerCase() !== "пропустить" && !isNaN(userInput)) {
            await new Promise((resolve, reject) => {
              db.run(
                "UPDATE users SET age = ? WHERE telegram_id = ?",
                [userInput, userId],
                (err) => {
                  if (err) reject(err);
                  resolve();
                }
              );
            });
            msgCtx.reply(`Возраст успешно обновлён на: ${userInput}`);
          }

          msgCtx.reply("Ваш профиль обновлён!");
          delete editState[userId];
          msgCtx.reply(
            "👤 Мой профиль",
            Markup.keyboard([
              ["🎯 Начать викторину", "👤 Мой профиль"],
              ["📊 Статистика", "📝 Редактировать профиль"],
              ["❓ Помощь"],
            ]).resize()
          );
        }
      });
    } else {
      ctx.reply(
        "❗ Ваш профиль не найден. Пожалуйста, начните регистрацию с команды /start."
      );
    }
  } catch (error) {
    console.error(error);
    ctx.reply("❗ Произошла ошибка при редактировании профиля.");
  }
});

bot.hears("📊 Статистика", async (ctx) => {
  try {
    const stats = await new Promise((resolve, reject) => {
      db.get(
        `
                SELECT 
                    COUNT(*) AS total_users, 
                    SUM(score) AS total_score, 
                    SUM(correct_answers) AS total_correct, 
                    SUM(incorrect_answers) AS total_incorrect
                FROM users
            `,
        (err, row) => {
          if (err) reject(err);
          resolve(row);
        }
      );
    });

    if (stats) {
      ctx.reply(`📊 Глобальная статистика:
- Всего пользователей: ${stats.total_users}
- Общий счёт: ${stats.total_score || 0}
- Всего правильных ответов: ${stats.total_correct || 0}
- Всего неправильных ответов: ${stats.total_incorrect || 0}`);
    } else {
      ctx.reply("❗ Статистика недоступна.");
    }
  } catch (error) {
    console.error(error);
    ctx.reply("❗ Произошла ошибка при получении статистики.");
  }
});

bot.hears("❓ Помощь", (ctx) => {
  ctx.reply(`⚡ Помощь:
1. Нажмите "🎯 Начать викторину", чтобы пройти тест.
2. "👤 Мой профиль" позволяет просматривать ваш профиль.
3. "📝 Редактировать профиль" позволяет изменить ваше имя и возраст.
4. "📊 Статистика" покажет глобальные результаты.
5. Для получения дополнительной помощи нажмите "❓ Помощь".`);
});

const userAnswers = {};

bot.hears("🎯 Начать викторину", async (ctx) => {
  const userId = ctx.from.id;
  let userScore = 0;
  let currentQuestion = 0;

  userAnswers[userId] = [];

  try {
    db.serialize(() => {
      db.run(
        'UPDATE users SET quiz_state = "in_progress" WHERE telegram_id = ?',
        [userId]
      );
    });

    const questions = await new Promise((resolve, reject) => {
      db.all(
        "SELECT * FROM questions ORDER BY RANDOM() LIMIT 10",
        (err, rows) => {
          if (err) {
            console.error("Ошибка при запросе вопросов:", err);
            reject(err);
          }
          if (!rows || rows.length === 0) {
            console.error("Вопросы не найдены.");
            return reject("Вопросы не найдены.");
          }
          console.log("Загруженные вопросы:", rows);
          resolve(rows);
        }
      );
    });

    if (questions.length === 0) {
      return ctx.reply("⚠️ Вопросы не загружены.");
    }

    const askQuestion = async () => {
      if (currentQuestion < questions.length) {
        const question = questions[currentQuestion];

        if (question.correct_option === undefined) {
          console.error(
            "Ошибка: правильный вариант ответа не найден для вопроса",
            question
          );
          return ctx.reply("❗ Произошла ошибка при обработке вопроса.");
        }

        userAnswers[userId].push({
          question: question.question,
          correctOption: question[`option${question.correct_option + 1}`],
        });

        const options = [
          Markup.button.callback(question.option1, "answer_0"),
          Markup.button.callback(question.option2, "answer_1"),
          Markup.button.callback(question.option3, "answer_2"),
        ];

        await ctx.reply(
          `❓ Вопрос ${currentQuestion + 1}: ${question.question}`,
          Markup.inlineKeyboard(options)
        );
      } else {
        db.serialize(() => {
          db.run(
            "UPDATE users SET score = score + ?, correct_answers = correct_answers + ?, incorrect_answers = incorrect_answers + ? WHERE telegram_id = ?",
            [userScore, userScore, 10 - userScore, userId]
          );
        });

        return ctx.reply(
          `🎉 Викторина завершена! Ваши баллы: ${userScore}`,
          Markup.keyboard([
            ["🎯 Начать викторину", "👤 Мой профиль"],
            ["📊 Статистика", "❓ Помощь"],
            ["📜 Посмотреть правильные ответы"],
          ]).resize()
        );
      }
    };

    bot.action(/answer_\d/, async (answerCtx) => {
      const selectedOption = parseInt(answerCtx.match[0].split("_")[1], 10);

      const question = questions[currentQuestion];
      if (!question || question.correct_option === undefined) {
        console.error("Ошибка: данные о вопросе не найдены.");
        return answerCtx.reply("❗ Произошла ошибка при обработке вопроса.");
      }

      const correctOption = question.correct_option;

      if (selectedOption === correctOption) {
        userScore++;
        db.serialize(() => {
          db.run(
            "UPDATE users SET correct_answers = correct_answers + 1 WHERE telegram_id = ?",
            [userId]
          );
        });
      } else {
        db.serialize(() => {
          db.run(
            "UPDATE users SET incorrect_answers = incorrect_answers + 1 WHERE telegram_id = ?",
            [userId]
          );
        });
      }

      currentQuestion++;

      if (currentQuestion < questions.length) {
        await answerCtx.answerCbQuery();
        await askQuestion();
      } else {
        db.serialize(() => {
          db.run(
            "UPDATE users SET score = score + ?, correct_answers = correct_answers + ?, incorrect_answers = incorrect_answers + ? WHERE telegram_id = ?",
            [userScore, userScore, 10 - userScore, userId]
          );
        });
        return answerCtx.reply(
          `🎉 Викторина завершена! Ваши баллы: ${userScore}`,
          Markup.keyboard([
            ["🎯 Начать викторину", "👤 Мой профиль"],
            ["📊 Статистика", "❓ Помощь"],
            ["📜 Посмотреть правильные ответы"],
          ]).resize()
        );
      }
    });

    askQuestion();
  } catch (error) {
    console.error(error);
    ctx.reply("❗ Произошла ошибка при запуске викторины.");
  }
});

bot.hears("📜 Посмотреть правильные ответы", async (ctx) => {
  const userId = ctx.from.id;

  if (!userAnswers[userId] || userAnswers[userId].length === 0) {
    return ctx.reply("❗ У вас еще нет правильных ответов.");
  }

  const correctAnswersMessage = userAnswers[userId]
    .map((item, index) => {
      return `
        📝 *Вопрос ${index + 1}:* ${item.question}
        ✅ *Правильный ответ:* ${item.correctOption}
        `.trim();
    })
    .join("\n\n");

  return ctx.replyWithMarkdown(
    `🎉 *Ваши правильные ответы:*\n\n${correctAnswersMessage}`,
    Markup.keyboard([
      ["🎯 Начать викторину", "👤 Мой профиль"],
      ["📊 Статистика", "❓ Помощь"],
    ]).resize()
  );
});

bot.launch();
