CREATE TABLE users (
    id INT IDENTITY(1,1) PRIMARY KEY,
    telegram_id BIGINT UNIQUE NOT NULL,
    username NVARCHAR(255),
    score INT DEFAULT 0,
    surveys_taken INT DEFAULT 0,
    correct_answers INT DEFAULT 0,
    incorrect_answers INT DEFAULT 0
);

CREATE TABLE questions (
    id INT IDENTITY(1,1) PRIMARY KEY,
    question NVARCHAR(255) NOT NULL,
    option1 NVARCHAR(255) NOT NULL,
    option2 NVARCHAR(255) NOT NULL,
    option3 NVARCHAR(255) NOT NULL,
    correct_option INT NOT NULL,
    CONSTRAINT chk_correct_option CHECK (correct_option BETWEEN 0 AND 2)
);

CREATE TABLE current_question (
    user_id BIGINT PRIMARY KEY,
    question_id INT DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(telegram_id)
);
