const sqlite3 = require('sqlite3').verbose();

let db = new sqlite3.Database('./vikt.db', (err) => {
    if (err) {
        console.error("Ошибка открытия базы данных:", err.message);
    } else {
        console.log("База данных подключена");
    }
});

db.run(`CREATE TABLE IF NOT EXISTS questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    question TEXT NOT NULL,
    option1 TEXT NOT NULL,
    option2 TEXT NOT NULL,
    option3 TEXT NOT NULL,
    correct_option INTEGER NOT NULL CHECK(correct_option IN (1, 2, 3))
)`, (err) => {
    if (err) {
        console.error("Ошибка создания таблицы вопросов:", err.message);
    } else {
        console.log("Таблица вопросов готова");

        db.run(`CREATE INDEX IF NOT EXISTS idx_question_text ON questions(question)`);

        const questions = [
            { question: "Какая планета является самой большой в Солнечной системе?", option1: "Земля", option2: "Юпитер", option3: "Сатурн", correct_option: 2 },
            { question: "Кто написал 'Войну и мир'?", option1: "Лев Толстой", option2: "Фёдор Достоевский", option3: "Александр Пушкин", correct_option: 1 },
            { question: "Как называется столица Франции?", option1: "Барселона", option2: "Париж", option3: "Рим", correct_option: 2 },
            { question: "Какой элемент является основным в составе воды?", option1: "Кислород", option2: "Водород", option3: "Азот", correct_option: 2 },
            { question: "Кто был первым человеком, ступившим на Луну?", option1: "Юрий Гагарин", option2: "Нил Армстронг", option3: "Алексей Леонов", correct_option: 2 },
            { question: "Какой язык является официальным в Бразилии?", option1: "Испанский", option2: "Португальский", option3: "Итальянский", correct_option: 2 },
            { question: "Какой цвет имеет кровь у большинства человек?", option1: "Красный", option2: "Зеленый", option3: "Синий", correct_option: 1 },
            { question: "Что является самым быстрым животным на Земле?", option1: "Человек", option2: "Ястреб", option3: "Гепард", correct_option: 3 },
            { question: "Какая страна известна своей архитектурой, включающей пирамиды?", option1: "Египет", option2: "Индия", option3: "Мексика", correct_option: 1 },
            { question: "Как называется самая высокая гора на Земле?", option1: "Эверест", option2: "Килиманджаро", option3: "Фудзи", correct_option: 1 },
            { question: "Какой элемент таблицы Менделеева имеет атомный номер 1?", option1: "Гелий", option2: "Водород", option3: "Кислород", correct_option: 2 },
            { question: "Кто является автором картины 'Мона Лиза'?", option1: "Винсент ван Гог", option2: "Пабло Пикассо", option3: "Леонардо да Винчи", correct_option: 3 },
            { question: "Какой элемент имеет символ 'O'?", option1: "Кислород", option2: "Углерод", option3: "Азот", correct_option: 1 },
            { question: "Что такое гравитация?", option1: "Сила притяжения", option2: "Сила отталкивания", option3: "Электрическое взаимодействие", correct_option: 1 },
            { question: "Какая страна является самой крупной по территории?", option1: "Россия", option2: "Канада", option3: "Китай", correct_option: 1 },
            { question: "Как называется основной закон в биологии, изучающий наследственность?", option1: "Эволюция", option2: "Генетика", option3: "Физиология", correct_option: 2 },
            { question: "Какой океан является самым большим по площади?", option1: "Атлантический", option2: "Тихий", option3: "Индийский", correct_option: 2 },
            { question: "Какое число является корнем из 25?", option1: "5", option2: "6", option3: "10", correct_option: 1 },
            { question: "Кто является создателем теории относительности?", option1: "Никола Тесла", option2: "Альберт Эйнштейн", option3: "Галилео Галилей", correct_option: 2 },
            { question: "Какой металл является основным в составе алюминиевых сплавов?", option1: "Алюминий", option2: "Магний", option3: "Цинк", correct_option: 1 },
            { question: "Какая река является самой длинной в мире?", option1: "Амазонка", option2: "Нил", option3: "Миссисипи", correct_option: 1 },
            { question: "Какой язык является официальным в Египте?", option1: "Арабский", option2: "Турецкий", option3: "Персидский", correct_option: 1 },
            { question: "Какая птица не может летать?", option1: "Сова", option2: "Еж", option3: "Страус", correct_option: 3 },
            { question: "Какая планета самая горячая?", option1: "Меркурий", option2: "Венера", option3: "Марс", correct_option: 2 },
            { question: "Кто первым установил принцип гелиоцентрической системы?", option1: "Галилео Галилей", option2: "Николай Коперник", option3: "Исаак Ньютон", correct_option: 2 },
            { question: "Какая птица является символом мира?", option1: "Голубь", option2: "Сорока", option3: "Ласточка", correct_option: 1 }
        ];

        questions.forEach((q) => {
            addQuestion(q.question, q.option1, q.option2, q.option3, q.correct_option);
        });
    }
});

function addQuestion(question, option1, option2, option3, correct_option) {
    db.get('SELECT id FROM questions WHERE question = ?', [question], (err, row) => {
        if (err) {
            console.error("Ошибка при проверке дублирования:", err.message);
        } else if (row) {
            console.log(`Вопрос "${question}" уже существует в базе данных.`);
        } else {
            db.run(`INSERT INTO questions (question, option1, option2, option3, correct_option) VALUES (?, ?, ?, ?, ?)`,
                [question, option1, option2, option3, correct_option], function (err) {
                    if (err) {
                        console.error("Ошибка добавления вопроса:", err.message);
                    } else {
                        console.log(`Вопрос "${question}" добавлен в базу данных`);
                    }
                });
        }
    });
}

function getQuestions(callback) {
    db.all('SELECT * FROM questions ORDER BY RANDOM() LIMIT 10', (err, rows) => {
        if (err) {
            console.error("Ошибка при получении вопросов:", err.message);
            return callback(err);
        }
        if (!rows || rows.length === 0) {
            console.error("Вопросы не найдены в базе данных.");
            return callback("Вопросы не найдены");
        }
        callback(null, rows);
    });
}

getQuestions((err, questions) => {
    if (err) {
        console.log("Ошибка при получении вопросов");
    } else {
        console.log("Вопросы для викторины:");
        questions.forEach((question, index) => {
            console.log(`${index + 1}. ${question.question}`);
            console.log(`1) ${question.option1}`);
            console.log(`2) ${question.option2}`);
            console.log(`3) ${question.option3}`);
            console.log(`Правильный ответ: ${question.correct_option}`);
            console.log('---');
        });
    }
});
